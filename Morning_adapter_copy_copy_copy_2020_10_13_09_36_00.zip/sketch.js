var banana,player,obstacle,obstacleImage,bananaImage,playerImage;
var bananaGroup,obstacleGroup,jungle,jungleImage;
var ground;
var score;


function preload(){
  
  playerImage =  loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("stone.png");
  jungleImage = loadImage("jungle.jpg");
  
}
function setup() {
  createCanvas(400, 400);
  
  jungle = createSprite(200,200,400,400);
  jungle.addImage(jungleImage);
  
  var ground = createSprite(200,340,800,10);
  
  player = createSprite(65,290,20,20);
  player.addAnimation (playerImage);
  
  bananaGroup = createGroup();
  obstacleGroup = createGroup();
  
  score = 0;
  
  
  
  
}

function draw() {
  background(220);
  ground.velocityX=-5;
  
  if(ground.x<0){
    
    ground.x=ground.width/2;
    
  }
  
  player.collide(ground);
  
  if((keyDown("space"))&&(player.y>287.95)){
    
    player.velocityY=-25;
    
    
  }
  
  if(bananaGroup.isTouching(player)){
    
    bananaGroup.destroyEach();
    score = score+2;
    
  }
  switch(score){
      
    case 10 : player.scale= 0.12;
      
      
      
      
      
  }
  if(obstacleGroup.isTouching(player)){
    
    player.scale = 0.2;
    
    
  }
  player.velocityY=player.velocityY+2;
  createBanana()
  createObstacles();
  drawSprites();
}
function createBanana(){
  
  if(World.frameCount%300===0){
    
    var banana = createSprite(400,randomNumber(200,220),20,20);
    banana.setAnimation("Banana");
    banana.velocityX=-5;
    banana.scale=0.05;
    banana.lifetime=200;
    bananaGroup.add(banana);
    
  }
  
  
}
function createObstacles(){
  
  if(World.frameCount%300===0){
    
    var rock = createSprite(400,300,20,20);
    rock.setAnimation("Stone");
    rock.scale=0.2;
    rock.velocityX=-5;
    rock.lifetime=200;
    obstacleGroup(rock);
  }
  
  
  
}